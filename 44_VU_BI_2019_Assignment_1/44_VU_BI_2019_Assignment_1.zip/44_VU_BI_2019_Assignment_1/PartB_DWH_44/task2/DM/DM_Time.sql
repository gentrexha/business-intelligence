
CREATE TABLE `DM_Time` (
	`Date` DATE NOT NULL,
	`DayNumberofMonth` INT NOT NULL,
	`MonthNumberofYear` INT NOT NULL,
	`CalendarYear` INT NOT NULL,
	CONSTRAINT PK_Time PRIMARY KEY (`Date`)
);

